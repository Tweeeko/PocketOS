# PocketOS

A pocket-sized smart-home companion: a round 1.75" AMOLED screen with an animated
character, controlled by touch and two side buttons, configured from a phone over
the home Wi-Fi. Local-first: no PocketOS account, cloud or subscription.

Built for two units, each with its own independent settings.

## Status

| Area | State |
|---|---|
| Design prototypes (device screen, settings website) | Done, browser mockups in `design/` |
| Proof-of-concept firmware (`firmware/`) | Written, **not yet run on hardware** |
| Settings contract (`docs/config-schema.json`) | v1 draft |
| Device API (`docs/api.md`) | v1 draft |
| Home Assistant connection | Not started |
| Full settings website | Not started (PoC page only) |
| Enclosure / dock | Using Waveshare's aluminium case for now |

Nothing is claimed to work until it is ticked off in `docs/testing.md` on real hardware.

## Hardware

Waveshare **ESP32-S3-Touch-AMOLED-1.75C-EN** (aluminium case, battery included).
ESP32-S3R8, 8 MB PSRAM, 32 MB flash, 466×466 CO5300 AMOLED, CST9217 touch,
AXP2101 power chip, PWR and BOOT side buttons. Pins and sources: `docs/hardware.md`.

## Repository layout

```
firmware/          ESP-IDF project for the device (C, LVGL 9)
  main/            app code: config, Wi-Fi, local web API, UI, buttons, power
  main/www/        the small settings page the device serves itself
design/            browser prototypes of the OS and settings website (reference only)
docs/              architecture, API, settings schema, hardware, flashing, testing
.devcontainer/     GitHub Codespaces setup with ESP-IDF, for building from an iPad
.github/workflows/ cloud build that produces flashable firmware files
```

## Building (from an iPad)

1. Open this repository on github.com and choose **Code → Codespaces → Create codespace**.
2. In the Codespace terminal:
   ```
   cd firmware
   idf.py set-target esp32s3
   idf.py build
   ```
3. Or let GitHub do it: every push runs **Actions → Build firmware** and attaches
   `pocketos-full.bin` (first flash) and `pocketos.bin` (over-the-air updates).

First flash needs a PC once; after that updates go over Wi-Fi. See `docs/flashing.md`.

## Credits

Board support from Waveshare's `esp32_s3_touch_amoled_1_75c` component (Apache-2.0),
pulled in as a dependency, not copied. AXP2101 register usage follows Waveshare's
Apache-2.0 example `01_AXP2101`. See `NOTICE`.

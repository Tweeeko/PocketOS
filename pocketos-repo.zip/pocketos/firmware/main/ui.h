#pragma once
#include <stdbool.h>
#include "config.h"

// All functions are safe to call from any task (they take the display lock).
void ui_start(void);                         // after bsp_display_start()
void ui_apply_config(const pocket_config_t *c);
void ui_refresh_status(void);                // network / battery changed
void ui_toggle_settings(void);               // BOOT short press
void ui_toggle_screen(void);                 // PWR short press
void ui_show_message(const char *text, int ms);
void ui_set_reset_pending(bool pending);
void ui_set_pin(const char *pin);

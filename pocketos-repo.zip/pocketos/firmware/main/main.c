// PocketOS proof-of-concept firmware.
// Goal: prove a phone on the home Wi-Fi can read and change a setting on the device,
// that it survives a restart, and that updates can be installed over Wi-Fi.
#include <stdlib.h>
#include <time.h>
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "bsp/esp-bsp.h"
#include "bsp/display.h"
#include "config.h"
#include "pmu.h"
#include "net.h"
#include "ui.h"
#include "web.h"
#include "buttons.h"

static const char *TAG = "pocketos";

static void on_config(const pocket_config_t *c)
{
    setenv("TZ", c->tz, 1);
    tzset();
    ui_apply_config(c);
}

static void on_button(button_event_t ev)
{
    switch (ev) {
    case BTN_BOOT_SHORT:
        if (web_reset_pending()) web_reset_confirmed();
        else ui_toggle_settings();
        break;
    case BTN_BOOT_LONG:
        ui_show_message("Voice is coming soon", 1500);
        break;
    case BTN_PWR_SHORT:
        ui_toggle_screen();
        break;
    case BTN_PWR_LONG:
        ui_show_message("Keep holding PWR to switch off", 2000);
        break;
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "PocketOS starting");
    ESP_ERROR_CHECK(config_init());

    ESP_ERROR_CHECK(bsp_i2c_init());
    if (pmu_init() != ESP_OK) ESP_LOGW(TAG, "power chip not found; battery info unavailable");

    if (bsp_display_start() == NULL) {
        ESP_LOGE(TAG, "display failed to start");
        return;   // no rollback mark: a broken update will roll back on next restart
    }

    ESP_ERROR_CHECK(net_start());
    ui_start();
    config_set_listener(on_config);
    net_set_listener(ui_refresh_status);
    ESP_ERROR_CHECK(web_start());
    buttons_start(on_button);

    // Everything essential started: keep this firmware (cancels automatic rollback).
    esp_ota_mark_app_valid_cancel_rollback();
    ESP_LOGI(TAG, "ready, device id %s", device_id());
}

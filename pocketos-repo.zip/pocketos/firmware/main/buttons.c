#include "buttons.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "pmu.h"

#define BOOT_GPIO GPIO_NUM_0
#define LONG_MS   1500

static button_handler_t s_handler;

static void button_task(void *arg)
{
    int held_ms = 0;
    bool long_sent = false;
    int pmu_tick = 0;
    for (;;) {
        bool down = gpio_get_level(BOOT_GPIO) == 0;
        if (down) {
            held_ms += 20;
            if (held_ms >= LONG_MS && !long_sent) { long_sent = true; s_handler(BTN_BOOT_LONG); }
        } else {
            if (held_ms >= 40 && !long_sent) s_handler(BTN_BOOT_SHORT);  // 40 ms debounce
            held_ms = 0;
            long_sent = false;
        }
        if (++pmu_tick >= 5) {   // poll the power chip every 100 ms
            pmu_tick = 0;
            pwr_event_t p = pmu_poll_pwr_key();
            if (p == PWR_SHORT) s_handler(BTN_PWR_SHORT);
            else if (p == PWR_LONG) s_handler(BTN_PWR_LONG);
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void buttons_start(button_handler_t handler)
{
    s_handler = handler;
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << BOOT_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    gpio_config(&io);
    xTaskCreate(button_task, "buttons", 3072, NULL, 5, NULL);
}

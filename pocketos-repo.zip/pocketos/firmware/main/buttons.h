#pragma once
// Side buttons.
//   BOOT (GPIO 0): short press = show/hide the Settings screen (QR + PIN),
//                  or confirm a reset requested from the website.
//                  Long press (>1.5 s) = reserved for voice (later).
//   PWR (via AXP2101): short press = screen off/on.
//                  Holding much longer powers the board off (power chip default).
typedef enum { BTN_BOOT_SHORT, BTN_BOOT_LONG, BTN_PWR_SHORT, BTN_PWR_LONG } button_event_t;
typedef void (*button_handler_t)(button_event_t ev);
void buttons_start(button_handler_t handler);

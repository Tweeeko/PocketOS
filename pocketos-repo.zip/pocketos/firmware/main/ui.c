// PocketOS screen (LVGL 9). Proof-of-concept: companion, clock, status, setup and
// settings screens. The full Liquid Glass UI from design/ comes later.
#include "ui.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "esp_random.h"
#include "lvgl.h"
#include "bsp/esp-bsp.h"
#include "bsp/display.h"
#include "net.h"
#include "pmu.h"

#define LOCK()   bsp_display_lock((uint32_t)-1)
#define UNLOCK() bsp_display_unlock()

static const uint32_t EYE_COLORS[EYE_COUNT] = {0x6AA7FF, 0x9B7BFF, 0xE8ECFF};

static lv_obj_t *scr_home, *scr_setup, *scr_settings;
static lv_obj_t *orb, *eye_l, *eye_r, *lbl_time, *lbl_status;
static lv_obj_t *setup_qr, *lbl_setup;
static lv_obj_t *settings_qr, *lbl_settings;
static lv_obj_t *toast;
static lv_timer_t *toast_timer;

static pocket_config_t s_cfg;
static char s_pin[8] = "------";
static bool s_asleep, s_reset_pending, s_happy;
static uint32_t s_asleep_at;

/* ---------- helpers ---------- */

static lv_obj_t *black_screen(void)
{
    lv_obj_t *s = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s, LV_OPA_COVER, 0);
    lv_obj_remove_flag(s, LV_OBJ_FLAG_SCROLLABLE);
    return s;
}

static lv_obj_t *label(lv_obj_t *parent, const lv_font_t *font, uint32_t color)
{
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    return l;
}

static lv_obj_t *qr(lv_obj_t *parent, int size)
{
    lv_obj_t *q = lv_qrcode_create(parent);
    lv_qrcode_set_size(q, size);
    lv_qrcode_set_dark_color(q, lv_color_black());
    lv_qrcode_set_light_color(q, lv_color_white());
    lv_obj_set_style_border_color(q, lv_color_white(), 0);
    lv_obj_set_style_border_width(q, 8, 0);
    return q;
}

static void set_eyes(int h, int y)
{
    lv_obj_set_height(eye_l, h);
    lv_obj_set_height(eye_r, h);
    lv_obj_align(eye_l, LV_ALIGN_CENTER, -38, y);
    lv_obj_align(eye_r, LV_ALIGN_CENTER, 38, y);
}

/* ---------- companion life ---------- */

static void unblink_cb(lv_timer_t *t) { if (!s_happy) set_eyes(40, -6); }

static void blink_cb(lv_timer_t *t)
{
    if (!s_happy && !s_asleep && lv_screen_active() == scr_home) {
        set_eyes(5, -6);
        lv_timer_t *u = lv_timer_create(unblink_cb, 120, NULL);
        lv_timer_set_repeat_count(u, 1);
    }
    lv_timer_set_period(t, 2500 + esp_random() % 3500);
}

static void unhappy_cb(lv_timer_t *t) { s_happy = false; set_eyes(40, -6); }

static void orb_clicked(lv_event_t *e)
{
    s_happy = true;
    set_eyes(14, -10);   // squint = smile
    lv_timer_t *u = lv_timer_create(unhappy_cb, 1200, NULL);
    lv_timer_set_repeat_count(u, 1);
}

/* ---------- status and clock ---------- */

static void refresh_status_nolock(void)
{
    net_status_t n;
    net_status(&n);
    char buf[96];
    int pct = pmu_battery_percent();
    char bat[24] = "";
    if (pct >= 0) snprintf(bat, sizeof(bat), "  %s %d%%", pmu_is_charging() ? LV_SYMBOL_CHARGE : LV_SYMBOL_BATTERY_3, pct);

    if (n.mode == NET_SETUP) snprintf(buf, sizeof(buf), "Setup mode%s", bat);
    else if (n.connected) snprintf(buf, sizeof(buf), LV_SYMBOL_WIFI " Home%s", bat);
    else snprintf(buf, sizeof(buf), "Looking for Wi-Fi...%s", bat);
    lv_label_set_text(lbl_status, buf);

    if (n.mode == NET_SETUP) {
        char q[128];
        snprintf(q, sizeof(q), "WIFI:T:WPA;S:%s;P:%s;;", n.ap_ssid, n.ap_pass);
        lv_qrcode_update(setup_qr, q, strlen(q));
        char t[200];
        snprintf(t, sizeof(t), "Scan to join my Wi-Fi\n%s  /  %s\nthen open 192.168.4.1", n.ap_ssid, n.ap_pass);
        lv_label_set_text(lbl_setup, t);
    }
}

static void clock_cb(lv_timer_t *t)
{
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);
    char buf[16];
    if (tm.tm_year < (2024 - 1900)) strcpy(buf, "--:--");
    else strftime(buf, sizeof(buf), s_cfg.clock_24h ? "%H:%M" : "%I:%M", &tm);
    if (!s_cfg.clock_24h && buf[0] == '0') memmove(buf, buf + 1, strlen(buf));
    lv_label_set_text(lbl_time, buf);

    static int n;
    if (++n % 15 == 0) refresh_status_nolock();   // battery every 15 s
}

/* ---------- sleep ---------- */

static void sleep_nolock(bool sleep)
{
    s_asleep = sleep;
    s_asleep_at = lv_tick_get();
    bsp_display_brightness_set(sleep ? 0 : s_cfg.brightness);
}

static void sleep_cb(lv_timer_t *t)
{
    uint32_t idle = lv_display_get_inactive_time(NULL);
    net_status_t n;
    net_status(&n);
    if (s_asleep) {
        if (idle < lv_tick_elaps(s_asleep_at)) sleep_nolock(false);   // touched since sleeping: wake
    } else if (n.mode == NET_NORMAL && s_cfg.sleep_s > 0 && !s_reset_pending &&
             idle > (uint32_t)s_cfg.sleep_s * 1000) {
        lv_screen_load(scr_home);
        sleep_nolock(true);
    }
}

/* ---------- screens ---------- */

static void build_home(void)
{
    scr_home = black_screen();
    lbl_time = label(scr_home, &lv_font_montserrat_28, 0xF1F3FF);
    lv_obj_align(lbl_time, LV_ALIGN_TOP_MID, 0, 62);

    orb = lv_obj_create(scr_home);
    lv_obj_set_size(orb, 230, 230);
    lv_obj_align(orb, LV_ALIGN_CENTER, 0, 10);
    lv_obj_set_style_radius(orb, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(orb, lv_color_hex(0x2A2F55), 0);
    lv_obj_set_style_bg_grad_color(orb, lv_color_hex(0x0C0E1C), 0);
    lv_obj_set_style_bg_grad_dir(orb, LV_GRAD_DIR_VER, 0);
    lv_obj_set_style_border_color(orb, lv_color_white(), 0);
    lv_obj_set_style_border_opa(orb, LV_OPA_20, 0);
    lv_obj_set_style_border_width(orb, 1, 0);
    lv_obj_set_style_shadow_color(orb, lv_color_hex(0x6AA7FF), 0);
    lv_obj_set_style_shadow_opa(orb, LV_OPA_30, 0);
    lv_obj_set_style_shadow_width(orb, 50, 0);
    lv_obj_remove_flag(orb, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(orb, orb_clicked, LV_EVENT_CLICKED, NULL);

    eye_l = lv_obj_create(orb);
    eye_r = lv_obj_create(orb);
    lv_obj_t *eyes[2] = {eye_l, eye_r};
    for (int i = 0; i < 2; i++) {
        lv_obj_set_size(eyes[i], 28, 40);
        lv_obj_set_style_radius(eyes[i], LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_border_width(eyes[i], 0, 0);
        lv_obj_set_style_shadow_width(eyes[i], 18, 0);
        lv_obj_set_style_shadow_opa(eyes[i], LV_OPA_60, 0);
        lv_obj_remove_flag(eyes[i], LV_OBJ_FLAG_CLICKABLE);
    }
    set_eyes(40, -6);

    lbl_status = label(scr_home, &lv_font_montserrat_20, 0x8B91AE);
    lv_obj_align(lbl_status, LV_ALIGN_BOTTOM_MID, 0, -62);
}

static void build_setup(void)
{
    scr_setup = black_screen();
    lv_obj_t *t = label(scr_setup, &lv_font_montserrat_28, 0xF1F3FF);
    lv_label_set_text(t, "Hi, I'm PocketOS");
    lv_obj_align(t, LV_ALIGN_TOP_MID, 0, 58);
    setup_qr = qr(scr_setup, 160);
    lv_obj_align(setup_qr, LV_ALIGN_CENTER, 0, -6);
    lbl_setup = label(scr_setup, &lv_font_montserrat_20, 0xC9CEE6);
    lv_obj_align(lbl_setup, LV_ALIGN_BOTTOM_MID, 0, -52);
}

static void build_settings(void)
{
    scr_settings = black_screen();
    lv_obj_t *t = label(scr_settings, &lv_font_montserrat_20, 0x8B91AE);
    lv_label_set_text(t, "Settings");
    lv_obj_align(t, LV_ALIGN_TOP_MID, 0, 50);
    settings_qr = qr(scr_settings, 160);
    lv_obj_align(settings_qr, LV_ALIGN_CENTER, 0, -14);
    lbl_settings = label(scr_settings, &lv_font_montserrat_20, 0xF1F3FF);
    lv_obj_align(lbl_settings, LV_ALIGN_BOTTOM_MID, 0, -46);
}

static void fill_settings_nolock(void)
{
    net_status_t n;
    net_status(&n);
    char url[64], txt[200];
    if (n.mode == NET_SETUP) {
        snprintf(url, sizeof(url), "http://192.168.4.1/");
        snprintf(txt, sizeof(txt), "Join %s first\nthen scan\nPIN  %s", n.ap_ssid, s_pin);
    } else if (n.connected) {
        snprintf(url, sizeof(url), "http://%s/", n.ip);
        snprintf(txt, sizeof(txt), "Scan on home Wi-Fi\n%s.local\nPIN  %s", n.host, s_pin);
    } else {
        snprintf(url, sizeof(url), "http://%s.local/", n.host);
        snprintf(txt, sizeof(txt), "Not on Wi-Fi yet\n%s.local\nPIN  %s", n.host, s_pin);
    }
    lv_qrcode_update(settings_qr, url, strlen(url));
    lv_label_set_text(lbl_settings, txt);
}

static void hide_toast_cb(lv_timer_t *t) { lv_obj_add_flag(toast, LV_OBJ_FLAG_HIDDEN); toast_timer = NULL; }

static void show_message_nolock(const char *text, int ms)
{
    lv_label_set_text(toast, text);
    lv_obj_remove_flag(toast, LV_OBJ_FLAG_HIDDEN);
    if (toast_timer) { lv_timer_delete(toast_timer); toast_timer = NULL; }
    if (ms > 0) {
        toast_timer = lv_timer_create(hide_toast_cb, ms, NULL);
        lv_timer_set_repeat_count(toast_timer, 1);
    }
}

static void apply_config_nolock(const pocket_config_t *c)
{
    s_cfg = *c;
    lv_color_t col = lv_color_hex(EYE_COLORS[c->eye]);
    lv_obj_set_style_bg_color(eye_l, col, 0);
    lv_obj_set_style_bg_color(eye_r, col, 0);
    lv_obj_set_style_shadow_color(eye_l, col, 0);
    lv_obj_set_style_shadow_color(eye_r, col, 0);
    if (!s_asleep) bsp_display_brightness_set(c->brightness);
}

/* ---------- public ---------- */

void ui_start(void)
{
    config_get(&s_cfg);
    LOCK();
    build_home();
    build_setup();
    build_settings();

    toast = label(lv_layer_top(), &lv_font_montserrat_20, 0xFFFFFF);
    lv_obj_set_style_bg_color(toast, lv_color_hex(0x14162A), 0);
    lv_obj_set_style_bg_opa(toast, LV_OPA_90, 0);
    lv_obj_set_style_radius(toast, 22, 0);
    lv_obj_set_style_pad_hor(toast, 18, 0);
    lv_obj_set_style_pad_ver(toast, 10, 0);
    lv_obj_set_style_border_color(toast, lv_color_white(), 0);
    lv_obj_set_style_border_opa(toast, LV_OPA_30, 0);
    lv_obj_set_style_border_width(toast, 1, 0);
    lv_obj_set_width(toast, 300);
    lv_obj_align(toast, LV_ALIGN_BOTTOM_MID, 0, -110);
    lv_obj_add_flag(toast, LV_OBJ_FLAG_HIDDEN);

    apply_config_nolock(&s_cfg);
    refresh_status_nolock();

    net_status_t n;
    net_status(&n);
    lv_screen_load(n.mode == NET_SETUP ? scr_setup : scr_home);

    lv_timer_create(blink_cb, 3000, NULL);
    lv_timer_create(clock_cb, 1000, NULL);
    lv_timer_create(sleep_cb, 300, NULL);
    clock_cb(NULL);
    UNLOCK();
}

void ui_apply_config(const pocket_config_t *c)
{
    LOCK();
    apply_config_nolock(c);
    show_message_nolock("Settings updated", 1500);
    UNLOCK();
}

void ui_refresh_status(void)
{
    LOCK();
    refresh_status_nolock();
    if (lv_screen_active() == scr_settings) fill_settings_nolock();
    UNLOCK();
}

void ui_toggle_settings(void)
{
    net_status_t n;
    net_status(&n);
    LOCK();
    lv_display_trigger_activity(NULL);
    if (s_asleep) sleep_nolock(false);
    if (lv_screen_active() == scr_settings) {
        lv_screen_load_anim(n.mode == NET_SETUP ? scr_setup : scr_home, LV_SCR_LOAD_ANIM_FADE_IN, 200, 0, false);
    } else {
        fill_settings_nolock();
        lv_screen_load_anim(scr_settings, LV_SCR_LOAD_ANIM_FADE_IN, 200, 0, false);
    }
    UNLOCK();
}

void ui_toggle_screen(void)
{
    LOCK();
    sleep_nolock(!s_asleep);
    if (!s_asleep) lv_display_trigger_activity(NULL);
    UNLOCK();
}

void ui_show_message(const char *text, int ms)
{
    LOCK();
    lv_display_trigger_activity(NULL);
    if (s_asleep) sleep_nolock(false);
    show_message_nolock(text, ms);
    UNLOCK();
}

void ui_set_reset_pending(bool pending)
{
    s_reset_pending = pending;
    if (pending) ui_show_message("Press BOOT to erase\nall settings", 0);
    else ui_show_message("Reset cancelled", 1500);
}

void ui_set_pin(const char *pin)
{
    LOCK();
    strncpy(s_pin, pin, sizeof(s_pin) - 1);
    if (lv_screen_active() == scr_settings) fill_settings_nolock();
    UNLOCK();
}

#include "config.h"
#include <string.h>
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_random.h"

static const char *TAG = "config";
static const char *NS = "pocketos";
static SemaphoreHandle_t s_lock;
static pocket_config_t s_cfg;
static config_listener_t s_listener;
static char s_id[5];

static const char *EYE_NAMES[EYE_COUNT] = {"blue", "violet", "white"};
static const int SLEEP_OPTIONS[] = {15, 30, 60, 0};

const char *config_eye_name(eye_t e) { return (e >= 0 && e < EYE_COUNT) ? EYE_NAMES[e] : "blue"; }

static void set_defaults(pocket_config_t *c)
{
    memset(c, 0, sizeof(*c));
    strcpy(c->name, "PocketOS");
    c->brightness = 80;
    c->clock_24h = true;
    c->sleep_s = 30;
    c->eye = EYE_BLUE;
    strcpy(c->tz, "GMT0BST,M3.5.0/1,M10.5.0");
}

const char *device_id(void)
{
    if (!s_id[0]) {
        uint8_t mac[6] = {0};
        esp_read_mac(mac, ESP_MAC_WIFI_STA);
        snprintf(s_id, sizeof(s_id), "%02x%02x", mac[4], mac[5]);
    }
    return s_id;
}

static void load_str(nvs_handle_t h, const char *key, char *dst, size_t len)
{
    size_t n = len;
    if (nvs_get_str(h, key, dst, &n) != ESP_OK) { /* keep default */ }
}

esp_err_t config_init(void)
{
    s_lock = xSemaphoreCreateMutex();
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS needs erase");
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    set_defaults(&s_cfg);
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READONLY, &h) == ESP_OK) {
        int32_t v;
        uint8_t b;
        load_str(h, "name", s_cfg.name, sizeof(s_cfg.name));
        if (nvs_get_i32(h, "bright", &v) == ESP_OK && v >= 10 && v <= 100) s_cfg.brightness = v;
        if (nvs_get_u8(h, "clk24", &b) == ESP_OK) s_cfg.clock_24h = b != 0;
        if (nvs_get_i32(h, "sleep", &v) == ESP_OK) {
            for (size_t i = 0; i < sizeof(SLEEP_OPTIONS) / sizeof(int); i++)
                if (SLEEP_OPTIONS[i] == v) s_cfg.sleep_s = v;
        }
        if (nvs_get_u8(h, "eye", &b) == ESP_OK && b < EYE_COUNT) s_cfg.eye = (eye_t)b;
        load_str(h, "tz", s_cfg.tz, sizeof(s_cfg.tz));
        nvs_close(h);
    }
    ESP_LOGI(TAG, "device %s, brightness %d", device_id(), s_cfg.brightness);
    return ESP_OK;
}

void config_get(pocket_config_t *out)
{
    xSemaphoreTake(s_lock, portMAX_DELAY);
    *out = s_cfg;
    xSemaphoreGive(s_lock);
}

void config_set_listener(config_listener_t fn) { s_listener = fn; }

static esp_err_t save(const pocket_config_t *c)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err |= nvs_set_str(h, "name", c->name);
    err |= nvs_set_i32(h, "bright", c->brightness);
    err |= nvs_set_u8(h, "clk24", c->clock_24h ? 1 : 0);
    err |= nvs_set_i32(h, "sleep", c->sleep_s);
    err |= nvs_set_u8(h, "eye", (uint8_t)c->eye);
    err |= nvs_set_str(h, "tz", c->tz);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err == ESP_OK ? ESP_OK : ESP_FAIL;
}

#define BAD(f, m) do { *bad_field = (f); *message = (m); return ESP_ERR_INVALID_ARG; } while (0)

esp_err_t config_apply_json(const cJSON *patch, const char **bad_field, const char **message)
{
    *bad_field = NULL;
    *message = NULL;
    if (!cJSON_IsObject(patch)) BAD(NULL, "Expected a JSON object");

    pocket_config_t next;
    config_get(&next);

    // Reject unknown keys so typos never look like a successful save.
    const cJSON *it;
    cJSON_ArrayForEach(it, patch) {
        const char *k = it->string;
        if (!strcmp(k, "name")) {
            if (!cJSON_IsString(it)) BAD("name", "Name must be text");
            size_t n = strlen(it->valuestring);
            if (n < 1 || n > 24) BAD("name", "Name must be 1 to 24 characters");
            strcpy(next.name, it->valuestring);
        } else if (!strcmp(k, "brightness")) {
            if (!cJSON_IsNumber(it) || it->valuedouble != (int)it->valuedouble) BAD("brightness", "Brightness must be a whole number");
            int v = it->valueint;
            if (v < 10 || v > 100) BAD("brightness", "Brightness must be between 10 and 100");
            next.brightness = v;
        } else if (!strcmp(k, "clock_24h")) {
            if (!cJSON_IsBool(it)) BAD("clock_24h", "clock_24h must be true or false");
            next.clock_24h = cJSON_IsTrue(it);
        } else if (!strcmp(k, "sleep_s")) {
            if (!cJSON_IsNumber(it)) BAD("sleep_s", "Sleep time must be a number");
            bool ok = false;
            for (size_t i = 0; i < sizeof(SLEEP_OPTIONS) / sizeof(int); i++)
                if (SLEEP_OPTIONS[i] == it->valueint && it->valuedouble == it->valueint) ok = true;
            if (!ok) BAD("sleep_s", "Sleep time must be 15, 30, 60 or 0");
            next.sleep_s = it->valueint;
        } else if (!strcmp(k, "eye")) {
            if (!cJSON_IsString(it)) BAD("eye", "Eye colour must be text");
            int found = -1;
            for (int i = 0; i < EYE_COUNT; i++) if (!strcmp(EYE_NAMES[i], it->valuestring)) found = i;
            if (found < 0) BAD("eye", "Eye colour must be blue, violet or white");
            next.eye = (eye_t)found;
        } else if (!strcmp(k, "tz")) {
            if (!cJSON_IsString(it)) BAD("tz", "Time zone must be text");
            size_t n = strlen(it->valuestring);
            if (n < 3 || n > 47) BAD("tz", "Time zone looks wrong");
            strcpy(next.tz, it->valuestring);
        } else {
            BAD(k, "Unknown setting");
        }
    }

    xSemaphoreTake(s_lock, portMAX_DELAY);
    esp_err_t err = save(&next);
    if (err == ESP_OK) s_cfg = next;
    xSemaphoreGive(s_lock);
    if (err != ESP_OK) BAD(NULL, "Couldn't save to the device's memory");

    if (s_listener) s_listener(&next);
    return ESP_OK;
}

cJSON *config_to_json(void)
{
    pocket_config_t c;
    config_get(&c);
    cJSON *v = cJSON_CreateObject();
    cJSON_AddStringToObject(v, "name", c.name);
    cJSON_AddNumberToObject(v, "brightness", c.brightness);
    cJSON_AddBoolToObject(v, "clock_24h", c.clock_24h);
    cJSON_AddNumberToObject(v, "sleep_s", c.sleep_s);
    cJSON_AddStringToObject(v, "eye", config_eye_name(c.eye));
    cJSON_AddStringToObject(v, "tz", c.tz);
    cJSON *root = cJSON_CreateObject();
    cJSON_AddNumberToObject(root, "schema", CONFIG_SCHEMA_VERSION);
    cJSON_AddItemToObject(root, "values", v);
    return root;
}

bool config_wifi_get(char *ssid, size_t ssid_len, char *pass, size_t pass_len)
{
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READONLY, &h) != ESP_OK) return false;
    size_t a = ssid_len, b = pass_len;
    bool ok = nvs_get_str(h, "ssid", ssid, &a) == ESP_OK && nvs_get_str(h, "pass", pass, &b) == ESP_OK && ssid[0];
    nvs_close(h);
    return ok;
}

esp_err_t config_wifi_set(const char *ssid, const char *pass)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_set_str(h, "ssid", ssid);
    if (err == ESP_OK) err = nvs_set_str(h, "pass", pass);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err;
}

void config_ap_password(char *out, size_t len)
{
    // 8 characters from an unambiguous alphabet, generated once per device.
    nvs_handle_t h;
    out[0] = 0;
    if (nvs_open(NS, NVS_READWRITE, &h) != ESP_OK) { strncpy(out, "pocketos", len); return; }
    size_t n = len;
    if (nvs_get_str(h, "ap_pass", out, &n) != ESP_OK || strlen(out) < 8) {
        static const char A[] = "abcdefghjkmnpqrstuvwxyz23456789";
        char p[9];
        for (int i = 0; i < 8; i++) p[i] = A[esp_random() % (sizeof(A) - 1)];
        p[8] = 0;
        nvs_set_str(h, "ap_pass", p);
        nvs_commit(h);
        strncpy(out, p, len);
        out[len - 1] = 0;
    }
    nvs_close(h);
}

esp_err_t config_factory_reset(void)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_erase_all(h);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err;
}

#pragma once
// AXP2101 power chip: battery level, charging state and the PWR side button.
#include <stdbool.h>
#include "esp_err.h"

typedef enum { PWR_NONE = 0, PWR_SHORT, PWR_LONG } pwr_event_t;

esp_err_t pmu_init(void);           // after bsp_i2c_init()
int pmu_battery_percent(void);      // -1 if no battery detected or read failed
bool pmu_is_charging(void);
pwr_event_t pmu_poll_pwr_key(void); // reads and clears the power-key interrupt flags

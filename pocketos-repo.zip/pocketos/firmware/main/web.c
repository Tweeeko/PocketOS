#include "web.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_system.h"
#include "esp_ota_ops.h"
#include "esp_app_desc.h"
#include "cJSON.h"
#include "config.h"
#include "net.h"
#include "pmu.h"
#include "ui.h"

static const char *TAG = "web";

extern const char index_html_start[] asm("_binary_index_html_start");
extern const char index_html_end[] asm("_binary_index_html_end");

#define MAX_TOKENS 4
static char s_tokens[MAX_TOKENS][33];
static int s_next_token;
static char s_pin[7];
static int s_bad_pins;
static int64_t s_locked_until_us;
static int64_t s_reset_deadline_us;
static esp_timer_handle_t s_restart_timer, s_reset_timer;

/* ---------- helpers ---------- */

static void new_pin(void)
{
    snprintf(s_pin, sizeof(s_pin), "%06lu", (unsigned long)(esp_random() % 1000000));
    ui_set_pin(s_pin);
}

static bool same(const char *a, const char *b)
{
    size_t la = strlen(a), lb = strlen(b);
    unsigned char d = la != lb;
    for (size_t i = 0; i < la && i < lb; i++) d |= a[i] ^ b[i];
    return d == 0;
}

static esp_err_t send_json(httpd_req_t *req, const char *status, cJSON *obj)
{
    char *s = cJSON_PrintUnformatted(obj);
    cJSON_Delete(obj);
    httpd_resp_set_status(req, status);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    esp_err_t r = httpd_resp_sendstr(req, s ? s : "{}");
    free(s);
    return r;
}

static esp_err_t send_error(httpd_req_t *req, const char *status, const char *msg, const char *field)
{
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "error", msg);
    if (field) cJSON_AddStringToObject(o, "field", field);
    return send_json(req, status, o);
}

static bool authorised(httpd_req_t *req)
{
    char h[64];
    if (httpd_req_get_hdr_value_str(req, "Authorization", h, sizeof(h)) != ESP_OK) return false;
    if (strncmp(h, "Bearer ", 7) != 0) return false;
    for (int i = 0; i < MAX_TOKENS; i++)
        if (s_tokens[i][0] && same(h + 7, s_tokens[i])) return true;
    return false;
}

#define REQUIRE_AUTH(req) do { if (!authorised(req)) return send_error(req, "401 Unauthorized", "Pair with the PIN on the device first", NULL); } while (0)

static cJSON *read_json(httpd_req_t *req)
{
    if (req->content_len <= 0 || req->content_len > 2048) return NULL;
    char *buf = calloc(1, req->content_len + 1);
    if (!buf) return NULL;
    int got = 0;
    while (got < req->content_len) {
        int r = httpd_req_recv(req, buf + got, req->content_len - got);
        if (r <= 0) { free(buf); return NULL; }
        got += r;
    }
    cJSON *j = cJSON_Parse(buf);
    free(buf);
    return j;
}

static bool in_setup(void)
{
    net_status_t n;
    net_status(&n);
    return n.mode == NET_SETUP;
}

/* ---------- handlers ---------- */

static esp_err_t h_index(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    return httpd_resp_send(req, index_html_start, index_html_end - index_html_start - 1);
}

static esp_err_t h_info(httpd_req_t *req)
{
    pocket_config_t c;
    config_get(&c);
    net_status_t n;
    net_status(&n);
    const esp_app_desc_t *app = esp_app_get_description();

    cJSON *o = cJSON_CreateObject();
    cJSON_AddNumberToObject(o, "api", 1);
    cJSON_AddNumberToObject(o, "schema", CONFIG_SCHEMA_VERSION);
    cJSON_AddStringToObject(o, "id", device_id());
    cJSON_AddStringToObject(o, "name", c.name);
    cJSON_AddStringToObject(o, "firmware", app->version);
    cJSON_AddStringToObject(o, "mode", n.mode == NET_SETUP ? "setup" : "normal");
    cJSON *w = cJSON_AddObjectToObject(o, "wifi");
    cJSON_AddStringToObject(w, "ssid", n.mode == NET_SETUP ? n.ap_ssid : n.ssid);
    cJSON_AddNumberToObject(w, "rssi", n.rssi);
    cJSON_AddStringToObject(w, "ip", n.ip);
    char host[48];
    snprintf(host, sizeof(host), "%s.local", n.host);
    cJSON_AddStringToObject(o, "host", host);
    cJSON *b = cJSON_AddObjectToObject(o, "battery");
    int pct = pmu_battery_percent();
    if (pct >= 0) cJSON_AddNumberToObject(b, "percent", pct); else cJSON_AddNullToObject(b, "percent");
    cJSON_AddBoolToObject(b, "charging", pmu_is_charging());
    cJSON_AddNumberToObject(o, "uptime_s", (double)(esp_timer_get_time() / 1000000));
    return send_json(req, "200 OK", o);
}

static esp_err_t h_pair(httpd_req_t *req)
{
    int64_t now = esp_timer_get_time();
    if (now < s_locked_until_us)
        return send_error(req, "429 Too Many Requests", "Too many wrong codes. Wait a minute and try again.", NULL);
    cJSON *j = read_json(req);
    const cJSON *pin = j ? cJSON_GetObjectItem(j, "pin") : NULL;
    bool ok = cJSON_IsString(pin) && same(pin->valuestring, s_pin);
    cJSON_Delete(j);
    if (!ok) {
        if (++s_bad_pins >= 5) { s_bad_pins = 0; s_locked_until_us = now + 60LL * 1000000; }
        return send_error(req, "401 Unauthorized", "That code doesn't match the one on PocketOS", "pin");
    }
    s_bad_pins = 0;
    char *tok = s_tokens[s_next_token];
    s_next_token = (s_next_token + 1) % MAX_TOKENS;
    for (int i = 0; i < 16; i++) sprintf(tok + i * 2, "%02x", (unsigned)(esp_random() & 0xff));
    new_pin();   // a code works once
    ui_show_message("Phone connected", 1500);
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "token", tok);
    return send_json(req, "200 OK", o);
}

static esp_err_t h_config_get(httpd_req_t *req)
{
    REQUIRE_AUTH(req);
    return send_json(req, "200 OK", config_to_json());
}

static esp_err_t h_config_post(httpd_req_t *req)
{
    REQUIRE_AUTH(req);
    cJSON *j = read_json(req);
    if (!j) return send_error(req, "400 Bad Request", "That wasn't valid settings data", NULL);
    const char *field, *msg;
    esp_err_t err = config_apply_json(j, &field, &msg);
    cJSON_Delete(j);
    if (err != ESP_OK) return send_error(req, "400 Bad Request", msg ? msg : "Not saved", field);
    return send_json(req, "200 OK", config_to_json());   // confirmation = what is now saved
}

static esp_err_t h_scan(httpd_req_t *req)
{
    if (!in_setup()) return send_error(req, "403 Forbidden", "Only available during first setup", NULL);
    net_ap_t aps[15];
    int n = net_scan(aps, 15);
    cJSON *o = cJSON_CreateObject();
    cJSON *arr = cJSON_AddArrayToObject(o, "networks");
    for (int i = 0; i < n; i++) {
        cJSON *e = cJSON_CreateObject();
        cJSON_AddStringToObject(e, "ssid", aps[i].ssid);
        cJSON_AddNumberToObject(e, "rssi", aps[i].rssi);
        cJSON_AddBoolToObject(e, "secure", aps[i].secure);
        cJSON_AddItemToArray(arr, e);
    }
    return send_json(req, "200 OK", o);
}

static void restart_cb(void *arg) { esp_restart(); }

static esp_err_t h_wifi(httpd_req_t *req)
{
    if (!in_setup()) return send_error(req, "403 Forbidden", "Only available during first setup", NULL);
    cJSON *j = read_json(req);
    const cJSON *ssid = j ? cJSON_GetObjectItem(j, "ssid") : NULL;
    const cJSON *pass = j ? cJSON_GetObjectItem(j, "password") : NULL;
    if (!cJSON_IsString(ssid) || !ssid->valuestring[0] || strlen(ssid->valuestring) > 32 ||
        (pass && (!cJSON_IsString(pass) || strlen(pass->valuestring) > 63))) {
        cJSON_Delete(j);
        return send_error(req, "400 Bad Request", "Choose a network and enter its password", "ssid");
    }
    ui_show_message("Joining your Wi-Fi...", 0);
    char ip[16] = "";
    esp_err_t err = net_try_join(ssid->valuestring, pass ? pass->valuestring : "", ip, sizeof(ip));
    cJSON_Delete(j);
    if (err != ESP_OK) {
        ui_show_message("Couldn't join that network", 3000);
        return send_error(req, "400 Bad Request", "Couldn't join that network. Check the password, and that it's 2.4 GHz.", "password");
    }
    ui_show_message("Joined! Restarting...", 0);
    net_status_t n;
    net_status(&n);
    char host[48];
    snprintf(host, sizeof(host), "%s.local", n.host);
    cJSON *o = cJSON_CreateObject();
    cJSON_AddBoolToObject(o, "ok", true);
    cJSON_AddStringToObject(o, "ip", ip);
    cJSON_AddStringToObject(o, "host", host);
    esp_timer_start_once(s_restart_timer, 3 * 1000 * 1000);
    return send_json(req, "200 OK", o);
}

static esp_err_t h_restart(httpd_req_t *req)
{
    REQUIRE_AUTH(req);
    ui_show_message("Restarting...", 0);
    esp_timer_start_once(s_restart_timer, 1000 * 1000);
    cJSON *o = cJSON_CreateObject();
    cJSON_AddBoolToObject(o, "ok", true);
    return send_json(req, "202 Accepted", o);
}

static void reset_expired_cb(void *arg)
{
    if (s_reset_deadline_us) { s_reset_deadline_us = 0; ui_set_reset_pending(false); }
}

static esp_err_t h_reset(httpd_req_t *req)
{
    REQUIRE_AUTH(req);
    s_reset_deadline_us = esp_timer_get_time() + 15LL * 1000000;
    esp_timer_stop(s_reset_timer);
    esp_timer_start_once(s_reset_timer, 15 * 1000 * 1000);
    ui_set_reset_pending(true);
    cJSON *o = cJSON_CreateObject();
    cJSON_AddBoolToObject(o, "ok", true);
    cJSON_AddStringToObject(o, "confirm", "Press BOOT on the device within 15 seconds");
    return send_json(req, "202 Accepted", o);
}

bool web_reset_pending(void)
{
    return s_reset_deadline_us && esp_timer_get_time() < s_reset_deadline_us;
}

void web_reset_confirmed(void)
{
    s_reset_deadline_us = 0;
    ui_show_message("Erasing...", 0);
    config_factory_reset();
    esp_timer_start_once(s_restart_timer, 800 * 1000);
}

static esp_err_t h_ota(httpd_req_t *req)
{
    REQUIRE_AUTH(req);
    const esp_partition_t *part = esp_ota_get_next_update_partition(NULL);
    if (!part) return send_error(req, "500 Internal Server Error", "No spare firmware slot", NULL);
    if (req->content_len <= 0 || req->content_len > part->size)
        return send_error(req, "400 Bad Request", "That file is the wrong size for PocketOS firmware", NULL);

    esp_ota_handle_t h;
    if (esp_ota_begin(part, OTA_WITH_SEQUENTIAL_WRITES, &h) != ESP_OK)
        return send_error(req, "500 Internal Server Error", "Couldn't start the update", NULL);
    ui_show_message("Updating...", 0);

    char *buf = malloc(4096);
    int left = req->content_len;
    esp_err_t err = buf ? ESP_OK : ESP_ERR_NO_MEM;
    while (err == ESP_OK && left > 0) {
        int r = httpd_req_recv(req, buf, left < 4096 ? left : 4096);
        if (r == HTTPD_SOCK_ERR_TIMEOUT) continue;
        if (r <= 0) { err = ESP_FAIL; break; }
        err = esp_ota_write(h, buf, r);
        left -= r;
    }
    free(buf);
    if (err == ESP_OK) err = esp_ota_end(h); else esp_ota_abort(h);
    if (err == ESP_OK) err = esp_ota_set_boot_partition(part);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "OTA failed: %s", esp_err_to_name(err));
        ui_show_message("Update failed. Nothing changed.", 4000);
        return send_error(req, "400 Bad Request", "Update failed. PocketOS is still on the old version.", NULL);
    }
    ui_show_message("Updated! Restarting...", 0);
    esp_timer_start_once(s_restart_timer, 1500 * 1000);
    cJSON *o = cJSON_CreateObject();
    cJSON_AddBoolToObject(o, "ok", true);
    return send_json(req, "200 OK", o);
}

static esp_err_t not_found(httpd_req_t *req, httpd_err_code_t code)
{
    if (in_setup()) {   // captive portal: send every unknown page to the setup page
        httpd_resp_set_status(req, "302 Found");
        httpd_resp_set_hdr(req, "Location", "http://192.168.4.1/");
        return httpd_resp_send(req, NULL, 0);
    }
    return send_error(req, "404 Not Found", "Not found", NULL);
}

/* ---------- start ---------- */

esp_err_t web_start(void)
{
    const esp_timer_create_args_t a = {.callback = restart_cb, .name = "restart"};
    const esp_timer_create_args_t b = {.callback = reset_expired_cb, .name = "reset_window"};
    esp_timer_create(&a, &s_restart_timer);
    esp_timer_create(&b, &s_reset_timer);
    new_pin();

    httpd_handle_t srv = NULL;
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.max_uri_handlers = 16;
    cfg.stack_size = 8192;
    cfg.recv_wait_timeout = 30;
    cfg.lru_purge_enable = true;
    esp_err_t err = httpd_start(&srv, &cfg);
    if (err != ESP_OK) return err;

    const httpd_uri_t uris[] = {
        {.uri = "/", .method = HTTP_GET, .handler = h_index},
        {.uri = "/api/v1/info", .method = HTTP_GET, .handler = h_info},
        {.uri = "/api/v1/pair", .method = HTTP_POST, .handler = h_pair},
        {.uri = "/api/v1/config", .method = HTTP_GET, .handler = h_config_get},
        {.uri = "/api/v1/config", .method = HTTP_POST, .handler = h_config_post},
        {.uri = "/api/v1/wifi/scan", .method = HTTP_GET, .handler = h_scan},
        {.uri = "/api/v1/wifi", .method = HTTP_POST, .handler = h_wifi},
        {.uri = "/api/v1/restart", .method = HTTP_POST, .handler = h_restart},
        {.uri = "/api/v1/reset", .method = HTTP_POST, .handler = h_reset},
        {.uri = "/api/v1/ota", .method = HTTP_POST, .handler = h_ota},
    };
    for (size_t i = 0; i < sizeof(uris) / sizeof(uris[0]); i++) httpd_register_uri_handler(srv, &uris[i]);
    httpd_register_err_handler(srv, HTTPD_404_NOT_FOUND, not_found);
    ESP_LOGI(TAG, "web server up");
    return ESP_OK;
}

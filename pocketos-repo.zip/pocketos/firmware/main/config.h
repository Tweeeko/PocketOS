#pragma once
// PocketOS settings. Names, limits and defaults must match docs/config-schema.json.
#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "cJSON.h"

#define CONFIG_SCHEMA_VERSION 1

typedef enum { EYE_BLUE = 0, EYE_VIOLET, EYE_WHITE, EYE_COUNT } eye_t;

typedef struct {
    char name[25];
    int brightness;     // 10..100
    bool clock_24h;
    int sleep_s;        // 15, 30, 60 or 0 (never)
    eye_t eye;
    char tz[48];
} pocket_config_t;

esp_err_t config_init(void);                 // load from NVS (defaults if missing)
void config_get(pocket_config_t *out);       // thread-safe copy
const char *config_eye_name(eye_t e);

// Validates every field in `patch` first; saves and applies only if all are valid.
// On error returns ESP_ERR_INVALID_ARG and sets *bad_field (static string).
esp_err_t config_apply_json(const cJSON *patch, const char **bad_field, const char **message);
cJSON *config_to_json(void);                 // caller frees

// Wi-Fi credentials and per-device secrets
bool config_wifi_get(char *ssid, size_t ssid_len, char *pass, size_t pass_len);
esp_err_t config_wifi_set(const char *ssid, const char *pass);
void config_ap_password(char *out, size_t len);  // generated once, then stored
esp_err_t config_factory_reset(void);            // erase everything in NVS

// Called after settings change (set by main.c)
typedef void (*config_listener_t)(const pocket_config_t *cfg);
void config_set_listener(config_listener_t fn);

// Device identity: "a1b2" from the last two bytes of the Wi-Fi MAC
const char *device_id(void);

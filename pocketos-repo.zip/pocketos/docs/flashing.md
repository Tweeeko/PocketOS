# Installing firmware

## First install (needs a PC once)

iPad Safari cannot talk to USB serial devices, so the very first install uses a PC
with Chrome or Edge. Nothing needs installing on the PC.

1. On the iPad, open the repository on GitHub → **Actions** → latest
   **Build firmware** run → download the **pocketos-firmware** artifact. Send the zip
   to the PC (AirDrop is not available to Windows; use iCloud Drive web, OneDrive or email).
2. On the PC, unzip it. You need `pocketos-full.bin`.
3. Open https://espressif.github.io/esptool-js/ in Chrome or Edge.
4. Plug PocketOS into the PC by USB-C. Click **Connect** and choose the port
   (often "USB JTAG/serial debug unit").
   If it does not appear: hold **BOOT**, tap **PWR** (or unplug/replug), release BOOT, try again.
5. Under **Flash address** enter `0x0`, choose `pocketos-full.bin`, click **Program**.
6. When it finishes, unplug and replug. The device should show its setup screen.

Repeat for the second unit.

## Updates after that (from the iPad, over Wi-Fi)

The proof-of-concept settings page has a **Firmware** section: pair, choose
`pocketos.bin` from the latest Actions artifact, upload. The device writes it to its
spare slot and restarts. If the new version fails to boot properly, it rolls back.

## Building in a Codespace instead

```
cd firmware
idf.py set-target esp32s3
idf.py build
idf.py merge-bin -o pocketos-full.bin
```

Files appear in `firmware/build/`. Download them via the Codespace file explorer.

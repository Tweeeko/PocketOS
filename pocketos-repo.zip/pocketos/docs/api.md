# Device API v1

Served by the device at `http://<device-address>/api/v1/...`. JSON in and out.
Authenticated calls send `Authorization: Bearer <token>`.

Errors always look like `{"error": "<human message>", "field": "<setting name, if any>"}`
with a 4xx/5xx status. The website must treat anything other than a 2xx response as
"nothing was changed".

## GET /api/v1/info  (no auth)

Identity and health, safe to show before pairing.

```json
{
  "api": 1, "schema": 1, "id": "a1b2", "name": "PocketOS",
  "firmware": "0.1.0", "mode": "normal",
  "wifi": {"ssid": "HomeNet", "rssi": -58, "ip": "192.168.1.42"},
  "host": "pocketos-a1b2.local",
  "battery": {"percent": 78, "charging": false},
  "uptime_s": 3600
}
```

`mode` is `"setup"` or `"normal"`. `battery.percent` is `null` if no battery is detected.

## POST /api/v1/pair  (no auth)

Body `{"pin": "482913"}` → `200 {"token": "<32 hex chars>"}`.
The PIN is shown on the device (press BOOT). Wrong PIN → `401`. After 5 wrong
attempts → `429` for 60 seconds. A new PIN is generated after each success and each boot.

## GET /api/v1/config  (auth)

`200 {"schema": 1, "values": {"name": "...", "brightness": 80, ...}}`

## POST /api/v1/config  (auth)

Body: any subset of settings, e.g. `{"brightness": 60}`.
All fields are validated first; if any is invalid nothing is saved (`400`, with `field`).
On success the device saves to flash, applies the change on screen, and returns the
full new config exactly as `GET` would. That response is the confirmation.

## GET /api/v1/wifi/scan  (setup mode only)

`200 {"networks": [{"ssid": "HomeNet", "rssi": -50, "secure": true}, ...]}`

## POST /api/v1/wifi  (setup mode only)

Body `{"ssid": "HomeNet", "password": "..."}`. The device tries to join while keeping
the setup network up (up to ~20 s).
- Success → `200 {"ok": true, "ip": "192.168.1.42", "host": "pocketos-a1b2.local"}`,
  then it saves and restarts into normal mode about 3 s later.
- Failure → `400 {"error": "Couldn't join that network. Check the password."}`, nothing saved.

## POST /api/v1/restart  (auth)

`202 {"ok": true}`, restarts after ~1 s. Settings are kept.

## POST /api/v1/reset  (auth)

`202 {"ok": true, "confirm": "Press BOOT on the device within 15 seconds"}`.
Only if BOOT is pressed in time does the device erase all settings and Wi-Fi and
restart into setup mode. Otherwise nothing happens.

## POST /api/v1/ota  (auth)

Body: the raw application binary (`pocketos.bin`, `Content-Type: application/octet-stream`).
Writes to the spare app slot, then `200 {"ok": true}` and restarts. If the new firmware
fails to start properly it rolls back to the previous one automatically.

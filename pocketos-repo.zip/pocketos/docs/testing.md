# Proof-of-concept test checklist

Tick only after doing it on a real unit. Record the phone/browser used.

## Build and flash
- [ ] GitHub Actions build passes and produces both .bin files
- [ ] First flash via esptool-js on a PC works (unit A)
- [ ] Same for unit B

## Setup mode
- [ ] Device shows "PocketOS-XXXX", a password and a Wi-Fi QR code
- [ ] iPhone joins by scanning the QR code
- [ ] Setup page opens on its own (captive portal); if not, http://192.168.4.1 works
- [ ] Wi-Fi list appears; a wrong password shows a clear error and nothing is saved
- [ ] Correct password: page shows the new address; device restarts on home Wi-Fi

## Normal mode
- [ ] iPhone on home Wi-Fi opens `http://pocketos-xxxx.local`
- [ ] Same via the IP address in the BOOT-button QR code
- [ ] Android phone opens it (note whether `.local` works)
- [ ] Pairing with the on-screen PIN works; wrong PIN is rejected; 5 wrong locks for 60 s
- [ ] Brightness change applies on screen immediately
- [ ] Brightness survives a restart (the key PoC test)
- [ ] Settings page shows "not saved" when the device is unplugged mid-change

## Buttons
- [ ] BOOT short press shows/hides the settings QR screen
- [ ] PWR short press turns the screen off/on
- [ ] Note the PWR hold time that hard-powers off: ____ s

## Two units
- [ ] Each shows a different ID; changing A's name does not change B

## OTA and recovery
- [ ] Upload `pocketos.bin` from iPad Safari; device restarts on new version
- [ ] Reset from the website only happens after pressing BOOT on the device
- [ ] After reset the device is back in setup mode

## Battery
- [ ] Battery % and charging state look plausible on the info screen

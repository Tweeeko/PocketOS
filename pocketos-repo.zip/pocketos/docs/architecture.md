# Architecture

## The short version

The **device is the source of truth**. It stores its own settings, serves its own
settings website, and (later) talks to Home Assistant directly. The phone is only an
editor. There is no PocketOS server anywhere.

```
 Phone (Safari)  ──HTTP on home Wi-Fi──▶  PocketOS  ──WebSocket──▶  Home Assistant
   settings page served                    settings in NVS            (phase 4)
   by the device itself                    local API /api/v1
```

## Why the device serves the website

A website hosted on the internet (HTTPS) is blocked by browsers from calling a device's
plain-HTTP address on the local network ("mixed content"), and Chrome adds further
local-network permission prompts. Serving the page from the device avoids all of this:
same origin, no CORS, nothing to host, works with no internet.

Cost: no HTTPS, so the page cannot be a full offline PWA, and traffic on the home
network is unencrypted. Mitigations are under "Security".

## Lifecycle

1. **Setup mode** (no saved Wi-Fi): the device creates `PocketOS-XXXX`, a WPA2 network
   whose password is generated once per device and shown on screen with a QR code.
   The phone joins it; a captive-portal redirect opens the setup page at 192.168.4.1.
   The user picks the home Wi-Fi. The device tests it while the setup network is still
   up, reports success (and its new address), saves it and restarts.
   **This network is used once.** It only returns after a full reset.
2. **Normal mode**: the device is on the home Wi-Fi as `pocketos-xxxx.local`.
   The phone reaches it like any web page. The BOOT button shows a QR code of the
   device's address plus a pairing PIN.
3. **Pairing**: the website asks for the 6-digit PIN shown on the device. The device
   returns a session token. Settings changes need that token.

## Two units

Each unit's ID is the last two bytes of its Wi-Fi MAC (`a1b2`). That ID is in its
network name, `.local` name, API responses and on the website header, so settings can
never be sent to the wrong unit. Settings live only in that unit's NVS.

## Security

| Risk | Mitigation |
|---|---|
| Anyone on the home Wi-Fi changing settings | Every write needs a token obtained with the on-screen PIN |
| PIN guessing | 5 wrong tries locks pairing for 60 s; new PIN each boot and after each pairing |
| Wiping the device remotely | Reset needs a token **and** a BOOT press on the device within 15 s |
| Rogue firmware upload | OTA needs a token; rollback if the new firmware doesn't boot cleanly |
| Sniffing on home Wi-Fi (no HTTPS) | Home Assistant token (phase 4) is write-only and never returned by the API |
| Setup network | WPA2 with per-device random password, only active until Wi-Fi is set |

Known PoC limitation: tokens are kept in RAM, so a restart means pairing again.

## Settings contract

`docs/config-schema.json` is the single list of setting names, types, limits and
defaults. Firmware (`config.c`) validates against the same limits and the website
reads them. Bump `schema_version` on any change.
